# Das Spiel der Lust – PWA

## Enthalten
- `index.html`: deine aktuelle Spielversion mit PWA-Metadaten und Service-Worker-Registrierung
- `manifest.webmanifest`: App-Name, Vollbildmodus, Farben und Symbole
- `sw.js`: Offline-Cache für die App-Shell und die Symbole
- `icons/`: App-Symbole

## Wichtig: PWA braucht HTTPS oder localhost
Eine installierbare PWA muss über eine sichere Webadresse (HTTPS) bereitgestellt werden. Eine HTML-Datei, die direkt aus `Downloads` geöffnet wird (`file://`), kann den Service Worker nicht aktivieren.

## Veröffentlichung ohne kostenpflichtigen Dienst
Du kannst das Projekt z. B. auf GitHub Pages oder Cloudflare Pages veröffentlichen. Diese Dienste haben kostenlose Optionen; du musst ein Konto anlegen und den Projektordner hochladen. Die Seite muss unter HTTPS erreichbar sein.

### Allgemeine Schritte (Hosting)
1. Erstelle ein Repository bei GitHub und lade alle Dateien und den Ordner `icons` hoch.
2. Aktiviere in den Repository-Einstellungen GitHub Pages für den Hauptbranch bzw. den Projektordner.
3. Öffne die veröffentlichte HTTPS-Adresse auf deinem Android-Handy in Chrome.
4. Tippe auf das Chrome-Menü (⋮) und wähle **App installieren** oder **Zum Startbildschirm hinzufügen**.
5. Bestätige die Installation. Die App erscheint anschließend als Symbol auf dem Startbildschirm.

Die genauen Menübezeichnungen hängen von der Chrome-Version ab.

## Offline-Funktion
Beim ersten Öffnen mit Internet werden HTML, Manifest und Symbole in den Cache geladen. Danach kann die App-Shell offline geöffnet werden. Bereits gespeicherte eigene Karten liegen lokal im Browser-/App-Speicher. Exportiere eigene Karten zusätzlich über die JSON-Funktion, bevor du Browserdaten löschst oder die App entfernst.

## Aktualisieren
Wenn du Dateien änderst, erhöhe `CACHE_NAME` in `sw.js` (z. B. auf `v2`), damit Geräte einen neuen Offline-Cache laden.
